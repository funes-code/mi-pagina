<?php
$host = "localhost";
$dbname = "mi_panaderia";  // Cambia esto por el nombre de tu base de datos
$username = "root";     // Cambia esto si usas un usuario diferente
$password = "";         // Cambia esto si tienes una contraseña establecida

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar a la base de datos: " . $e->getMessage());
}
?>